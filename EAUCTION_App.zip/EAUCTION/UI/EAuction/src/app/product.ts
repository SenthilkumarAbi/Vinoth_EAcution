export interface Product {
  _id:string;
productName:string;
shortDescription:string;
detailedDescription:string;
category:string;
startingPrice:number;
bidEndDate:string;
}

