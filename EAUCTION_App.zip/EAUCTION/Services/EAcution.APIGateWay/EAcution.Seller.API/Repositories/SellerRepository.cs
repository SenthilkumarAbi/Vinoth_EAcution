﻿using EAcution.Seller.API.Repositories.Interfaces;
using Model=EAcution.Models;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EAcution.Models;

namespace EAcution.Seller.API.Repositories
{
    public class SellerRepository : ISellerRepository
    {
        private readonly Model.AppSetting _appSettingAccessor;
        private IMongoDatabase _iMongoDBDatabase;
        public SellerRepository(IOptions<Model.AppSetting> appSettingAccessor)
        {
            _appSettingAccessor = appSettingAccessor.Value;
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            _iMongoDBDatabase = client.GetDatabase(_appSettingAccessor.DatabaseName);
        }

        public List<Model.Product> GetAllProduct()
        {
            return _iMongoDBDatabase.GetCollection<Model.Product>(Model.DBConstants.Product).Find(new BsonDocument()).ToList();
        }

        public Model.Product InsertProduct(Model.Product product)
        {
            var _products = _iMongoDBDatabase.GetCollection<Model.Product>(Model.DBConstants.Product);
            Model.Product _product = new Model.Product()
            {
                ProductName= product.ProductName,
                ShortDescription = product.ShortDescription,
                DetailedDescription = product.DetailedDescription,
                Category = product.Category,
                StartingPrice = product.StartingPrice,
                BidEndDate = product.BidEndDate
            };
            _products.InsertOne(_product);
            return _product;
        }

        public Model.Seller InsertSeller(Model.Seller seller)
        {
            var _sellers = _iMongoDBDatabase.GetCollection<Model.Seller>(Model.DBConstants.Seller);
            Model.Seller _seller = new Model.Seller()
            {
                FirstName= seller.FirstName,
                LastName = seller.LastName,
                Address = seller.Address,
                City = seller.City,
                State = seller.State,
                Pin = seller.Pin,
                Phone = seller.Phone,
                Email = seller.Email
            };
            _sellers.InsertOne(_seller);
            return _seller;
        }
        public string DeleteProduct(string productId)
        {
            var _filterProduct = Builders<Product>.Filter.Eq("_id", productId);
            var _products = _iMongoDBDatabase.GetCollection<Product>(Model.DBConstants.Product);
            _products.DeleteOne(_filterProduct);
            return "success";
        }
    }
}
