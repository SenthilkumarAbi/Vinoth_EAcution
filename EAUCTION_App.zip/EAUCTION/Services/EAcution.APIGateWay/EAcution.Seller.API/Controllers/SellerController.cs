﻿using EAcution.Seller.API.Processor.Interfaces;
using EAuction.Common.Utility.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Seller.API.Controllers
{
    [ApiController]
    [Route("api/v1/Seller")]
    public class SellerController : ControllerBase
    {
        public ISellerProcessor _sellerProcessor;
        public IUtility _utility;
        public IConfiguration _configuration;
        public SellerController(ISellerProcessor sellerProcessor,IUtility utility, IConfiguration configuration)
        {
            this._sellerProcessor = sellerProcessor;
            this._utility = utility;
            this._configuration = configuration;
        }
        [HttpGet]
        public string Get()
        {
            return "Seller";
        }
        [HttpPost]
        [Route("InsertSeller")]
        public Model.Seller InsertSeller([FromBody] Model.Seller seller)
        {
            return _sellerProcessor.InsertSeller(seller);
        }
        [HttpGet]
        [Route("GetAllCategory")]
        public List<string> GetAllCategory()
        {
            return new List<string> { "Painting", "Sculptor", "Ornament" };
        }
        [HttpPost]
        [Route("InsertProduct")]
        public string InsertProduct([FromBody] Model.Product product)
        {
            string msg=string.Empty;
            if(GetAllCategory().Exists(x=>x.Equals(product.Category))){ 
               Model.Product _product= _sellerProcessor.InsertProduct(product);
                msg = "Product insert successfully.";
            }
            else
            {
                msg = "Please enter any one of the given category(Painting/Sculptor/Ornament).";
            }
            return msg;
        }
        [HttpGet]
        [Route("GetAllProduct")]
        public List<Model.Product> GetAllProduct()
        {
            return _sellerProcessor.GetAllProduct();
        }
        [HttpDelete]
        [Route("DeleteProduct/{ProductName}")]
        public async Task<string> DeleteProduct(string ProductName)
        {
            string apiResponse = "Failed";
            List<Model.Product> lstProduct = _sellerProcessor.GetAllProduct();
            Model.Product product = lstProduct.Find(x => x.ProductName.Equals(ProductName));
            if (product != null) { 
                DateTime todayDate = DateTime.Now;
                string[] formats = { "MM-dd-yyyy" };
                DateTime bidDate = DateTime.ParseExact(product.BidEndDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                if (bidDate> todayDate) { 
                    //Delete all Bid under product ID
                    string apiUrl = _configuration.GetValue<string>("ApiGateWaySettings:URL").ToString();
                    double timeout = _configuration.GetValue<double>("ApiGateWaySettings:TimeOut");
                   
                    /*string deleteBid = string.Format(_configuration.GetValue<string>("ApiGateWaySettings:BuyerMicroService:DeleteBid").ToString(), product._id);
                    HttpClient httpClient = _utility.HttpRequstHeader(apiUrl, timeout);
                    using (var response = await httpClient.DeleteAsync(deleteBid))
                    {
                         apiResponse = await response.Content.ReadAsStringAsync();
                    }
                    //Delete product by product ID
                    if (apiResponse.Equals("success"))
                    {
                        apiResponse = this._sellerProcessor.DeleteProduct(product._id);
                    }*/

                    string getAllBuyer = _configuration.GetValue<string>("ApiGateWaySettings:BuyerMicroService:GetAllBuyer").ToString();
                    HttpClient httpClient = _utility.HttpRequstHeader(apiUrl, timeout);
                    using (var response = await httpClient.GetAsync(getAllBuyer))
                    {
                        string apiBuyerResponse = await response.Content.ReadAsStringAsync();
                        //Get All Byers
                        List<Model.Buyer> lstBuyer = JsonConvert.DeserializeObject<List<Model.Buyer>>(apiBuyerResponse);

                        //Get All Byers By Product ID & Descending by BidAmount
                        List<Model.Buyer> lstBitCountByProductId = lstBuyer.FindAll(x => x.ProductId.Equals(product._id)).OrderByDescending(x => x.BidAmount).ToList();
                        if (lstBitCountByProductId.Count == 0)
                        {
                            apiResponse = this._sellerProcessor.DeleteProduct(product._id);
                            apiResponse = "Product deleted sucessfully.";
                        }
                        else
                        {
                            apiResponse = "Unable to delete the product because some Bids mapped to this product.";
                        }
                    }
                }
                else
                {
                    apiResponse = "Sorry Bid Date ended.Could not be delete.";
                }
            }
            else
            {
                apiResponse = "Given product is not exists.";
            }
            return apiResponse;
        }
        [HttpGet]
        [Route("GetAllBidsByProductName/{ProductName}")]
        public async Task<Model.Product> GetAllBidsByProductName(string ProductName)
        {
            List<Model.Product> lstProduct=_sellerProcessor.GetAllProduct();
            Model.Product product=lstProduct.Find(x => x.ProductName.Equals(ProductName));
            if (product != null)
            {
                string apiUrl = _configuration.GetValue<string>("ApiGateWaySettings:URL").ToString();
                double timeout = _configuration.GetValue<double>("ApiGateWaySettings:TimeOut");
                string getAllBuyer = _configuration.GetValue<string>("ApiGateWaySettings:BuyerMicroService:GetAllBuyer").ToString();
                HttpClient httpClient = _utility.HttpRequstHeader(apiUrl, timeout);
                using (var response = await httpClient.GetAsync(getAllBuyer))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    //Get All Byers
                    List<Model.Buyer> lstBuyer = JsonConvert.DeserializeObject<List<Model.Buyer>>(apiResponse);

                    //Get All Byers By Product ID & Descending by BidAmount
                    List<Model.Buyer> lstBuyerbyProduct = lstBuyer.FindAll(x => x.ProductId.Equals(product._id)).OrderByDescending(x=>x.BidAmount).ToList();
                    product.Buyers = new List<Model.Buyer>();
                    product.Buyers = lstBuyerbyProduct;
                }
            }
            return product;
        }
    }
}
