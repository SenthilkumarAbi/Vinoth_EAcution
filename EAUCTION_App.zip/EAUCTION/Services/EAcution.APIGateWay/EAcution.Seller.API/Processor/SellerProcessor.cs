﻿using EAcution.Seller.API.Processor.Interfaces;
using EAcution.Seller.API.Repositories.Interfaces;
using EAcution.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Seller.API.Processor
{
    public class SellerProcessor : ISellerProcessor
    {
        public ISellerRepository _sellerRepository;
        public SellerProcessor(ISellerRepository sellerRepository)
        {
            this._sellerRepository = sellerRepository;
        }
        public string DeleteProduct(string productid)
        {
            return _sellerRepository.DeleteProduct(productid);
        }
        public List<Product> GetAllProduct()
        {
            return _sellerRepository.GetAllProduct();
        }
        public Product InsertProduct(Product product)
        {
            return _sellerRepository.InsertProduct(product);
        }
        public Model.Seller InsertSeller(Model.Seller seller)
        {
            return _sellerRepository.InsertSeller(seller);
        }
    }
}
