﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EAcution.Models
{
    public  class DBConstants
    {
        public static string Product = "Product";
        public static string Buyer = "Buyer";
        public static string Seller = "Seller";
    }
}
