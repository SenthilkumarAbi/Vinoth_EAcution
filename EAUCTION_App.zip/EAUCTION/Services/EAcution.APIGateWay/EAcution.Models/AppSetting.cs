﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EAcution.Models
{
    public class AppSetting
    {
        public string DatabaseConnectionString { get; set; }
        public string DatabaseName { get; set; }
    }
}
