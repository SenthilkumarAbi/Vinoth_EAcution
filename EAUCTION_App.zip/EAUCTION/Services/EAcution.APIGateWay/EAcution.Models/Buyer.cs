﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EAcution.Models
{
    public class Buyer
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }

        [Required(ErrorMessage = "Please enter First name")]
        [StringLength(30, MinimumLength =5)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter Last name")]
        [StringLength(25, MinimumLength = 3)]
        public string LastName { get; set; }


        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pin { get; set; }

        [Required(ErrorMessage = "Mobile no. is required")]
        [StringLength(10, MinimumLength = 10)]
        //[RegularExpression("^(?!0+$)(\\+\\d{1,3}[- ]?)?(?!0+$)\\d{10,15}$", ErrorMessage = "Please enter valid phone no.")]
        public string Phone { get; set; }


        [Required]
        [DataType(DataType.EmailAddress)]
        //[EmailAddress]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string Email { get; set; }
        
        public string ProductId { get; set; }

        [Required(ErrorMessage = "Please enter Product Name")]
        public string ProductName { get; set; }
        public double BidAmount { get; set; }
    }
}
