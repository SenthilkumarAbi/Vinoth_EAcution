﻿using EAuction.Common.Utility.Interfaces;
using System;
using System.Net;
using System.Net.Http;

namespace EAuction.Common.Utility
{
    public class Utility:IUtility
    {
        Uri uri = null;
        HttpClient httpClient = null;
        public HttpClient HttpRequstHeader(string uriPath,double timeout)
        {
            uri = new Uri(uriPath);
            var credentialsCache = new CredentialCache { { uri,"NTLM",CredentialCache.DefaultNetworkCredentials} };
            var handler = new HttpClientHandler { Credentials=credentialsCache};
            httpClient = new HttpClient(handler) { BaseAddress = uri, Timeout = TimeSpan.FromMinutes(timeout) };
            httpClient.DefaultRequestHeaders.ConnectionClose = false;
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            return httpClient;
        }
    }
}
