﻿using EAcution.Buyer.API.Processor.Interfaces;
using EAcution.Buyer.API.Repositories.Interfaces;
using EAcution.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Buyer.API.Processor
{
    public class BuyerProcessor : IBuyerProcessor
    {
        public IBuyerRepository _buyerRepository;
        public BuyerProcessor(IBuyerRepository buyerRepository)
        {
            this._buyerRepository = buyerRepository;
        }
        public List<Model.Buyer> getAllBuyers()
        {
            return this._buyerRepository.getAllBuyers();
        }
        public Model.Buyer PlaceBid(Model.Buyer buyer)
        {
            return this._buyerRepository.PlaceBid(buyer);
        }

        public Model.Buyer updateBid(Model.Buyer buyerinfo)
        {
            return this._buyerRepository.updateBid(buyerinfo);
        }
        public string DeleteBuyers(string productId)
        {
            return this._buyerRepository.DeleteBuyers(productId);
        }
    }
}
