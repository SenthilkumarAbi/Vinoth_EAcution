using EAcution.Buyer.API.Processor;
using EAcution.Buyer.API.Processor.Interfaces;
using EAcution.Buyer.API.Repositories;
using EAcution.Buyer.API.Repositories.Interfaces;
using EAcution.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EAuction.Common.Utility.Interfaces;
using EAuction.Common.Utility;

namespace EAcution.Buyer.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<IConfigurationRoot>(Configuration);
            services.Configure<AppSetting>(options =>
            {
                options.DatabaseConnectionString = Configuration.GetConnectionString("MongoDBConnectionString");
                options.DatabaseName = Configuration.GetConnectionString("DatabaseName");
            });
            services.AddControllers();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "EAcution.Buyer.API",
                    Version = "v1",
                    Description = "Buyer Micro Service"
                });
            });
            services.AddScoped<IBuyerRepository, BuyerRepository>();
            services.AddScoped<IBuyerProcessor, BuyerProcessor>();
            services.AddScoped<IUtility, Utility>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseSwagger();
            app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v1/swagger.json", "EAcution.Buyer.API v1"));
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
